# Clear theme for Shower
